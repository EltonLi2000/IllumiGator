# IllumiGator
2D Light-Based Puzzle Game

## Source Code and Other Resources
https://github.com/EltonLi2000/IllumiGator

https://drive.google.com/drive/folders/1HQ1lIxgZJNANgWnts3bsWUUTnnfJrKXW?usp=sharing

(contains timesheet and project ideas)

## Dependencies
arcade
numpy
screeninfo

## Install
pip install illumigator

run **illumigator** command
